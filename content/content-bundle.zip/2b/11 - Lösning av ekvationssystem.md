# 11 - Lösning av ekvationssystem 2

---

##### Syfte och mål
- Repetera "substitutionsmetoden"
- Använda metoden själv och i grupp

**Lärobok:** s.47-49
**Uppgifter:** 1317, 1319, 1320, 1321 (1323)
*(Bedöm alltid själv vilka uppgifter du behöver!)*
*(Se tidigare lektion för uppgifterna)*

---

#### Metoden

1. Lös ut en variabel ur den ena ekvationen
2. Ersätt variabeln i den andra ekvationen med detta uttryck och lös ekvationen
3. Sätt in lösningen till ekvationen i någon av de ursprungliga ekvationerna. Lös därefter den ekvationen
4. Kontrollera lösningen i de ursprungliga ekvationerna.

---

#### Gemensamt exempel

$$
\begin{cases}
y= 3x - 2 \\
y=4 -2x\\
\end{cases}
$$

---

#### Gruppuppgift
$$
\begin{cases}
3x -4y=17 \\
x -5 y =2\\
\end{cases}
$$
---

Välj en av ekvationer och lös ut variabeln
$$
x -5y =2 => x=5y +2
$$

---

Sätt in det nya uttrycket i den andra ekvationen

$$
3x -4y = 17 => 3(5y+2)-4y=17
$$

---

#### Eget arbete

- Se uppgifter föregående lektion
- Bonus: "Additionsmetoden" s. 48-52

---

#### Nästa vecka

- Läxa finns på Canvas!
- Ytterligare en lektion på ekvationssystem


