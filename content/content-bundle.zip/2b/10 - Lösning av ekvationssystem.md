# 10 - Lösning av ekvationssystem

##### Syfte och mål
- Repetera vad ett ekvationssystem är
- Bekanta sig med en lösningsmetod för ekvationssystem

**Lärobok:** s.47-49
**Uppgifter:** 1317, 1319, 1320, 1321 (1323)
*(Bedöm alltid själv vilka uppgifter du behöver!)*
### Genomgång
![](https://i.imgur.com/mmfl3wI.jpg)
![](https://i.imgur.com/4tn4JKQ.jpg)
### Uppgifter



![](https://i.imgur.com/JNFOCaY.png)
![](https://i.imgur.com/sz3mbCK.png)
