# 6 - Ekvationer

##### Syfte och mål
* Definiera ekvation och dess betydelse
* Hantera och lösa ekvationer av enklare typ

**Exponent 1c**: 
- [2.2 - Linjära ekvationer](https://gleerupsportal.se/laromedel/exponent-1c/article/dc57ca97-f528-4219-b79e-0937c3cb7634)  
- [2.2 - Ekvationer med parenteser](https://gleerupsportal.se/laromedel/exponent-1c/article/2fb49734-8c99-497b-bea3-cb0c48799873)
- [2.2 - Ekvationer med variabelterm i bägge leden](https://gleerupsportal.se/laromedel/exponent-1c/article/058f0217-478b-47bc-bba0-d8e38853907e)

**Uppgifter:** 2047 - 2071

### Genomgång
![[ekvation1.jpg]]
![[ekvation2.jpg]]
