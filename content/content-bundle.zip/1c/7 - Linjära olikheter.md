# 7 - Linjära olikheter

##### Syfte och mål
- Definiera de matematiska symbolerna för olikheter
- Hantera olikheter liknande ekvationer

**Lärobok:** [2.3 - Linjära olikheter](https://gleerupsportal.se/laromedel/exponent-1c/article/d64477a5-cd6c-448b-98f3-377bcd356f9b)
**Uppgifter:** 2099-2013
*(Bedöm alltid själv vilka uppgifter du behöver!)*
### Genomgång
![](https://i.imgur.com/Owa8UH5.jpg)




