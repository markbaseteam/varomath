# 13 - Procentuell förändring

##### Syfte och mål
- Jämföra procentuella förändringar
- Repetera skillnaden mellan förändringsfaktor och procent
- Skillnad procent och procentenhet
---

**Lärobok:** 76-78
**Uppgifter:** 1553, 1555, 1557, 1558, 1560 (1562)
*(Bedöm alltid själv vilka uppgifter du behöver!)*

---
### Genomgång
![](https://i.imgur.com/HKHnlbp.jpg)
![](https://i.imgur.com/ppZ2928.jpg)
![](https://i.imgur.com/AgLowWR.jpg)

---

### Uppgifter

![](https://i.imgur.com/j55drvV.png)

![](https://i.imgur.com/KGCpdLC.png)


